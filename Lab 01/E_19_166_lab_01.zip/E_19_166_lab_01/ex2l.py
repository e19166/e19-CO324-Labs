from urllib import request, parse

search_term = "විශූලා"
encoded_search_term = parse.quote(search_term)

with request.urlopen("https://www.duckduckgo.com/?q={search_term}") as query:

    headers = query.headers.items()
    body = query.read()
    
print(headers)
print(body)
