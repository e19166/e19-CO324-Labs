from urllib import request

response = request.urlopen("http://eng.pdn.ac.lk")
items = response.headers.items()
body = response.read()
response.close()

for header, value in response.headers.items():
    print(f"{header}: {value}")
