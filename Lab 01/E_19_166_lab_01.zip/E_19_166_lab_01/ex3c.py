import requests
from typing import Optional

def last_modified(url: str) -> Optional[str]:
    try:
        response = requests.head(url, method = 'HEAD')

        last_modified = response.headers.get('Last-Modified')

        return last_modified

    except Exception as e:
        return None

print(last_modified("http://eng.pdn.ac.lk"))
