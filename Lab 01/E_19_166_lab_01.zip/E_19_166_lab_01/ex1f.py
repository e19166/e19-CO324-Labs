from urllib import request

url1 = "http://eng.pdn.ac.lk/unknown"
url2 = "http://unknown.pdn.ac.lk"

### First URL
#response1 = request.urlopen(url1)
#print("Response Code for", url1, ":",response1.getcode())

### Second URL
response2 = request.urlopen(url2)
print("Response Code for", url2, ":",response2.getcode())


