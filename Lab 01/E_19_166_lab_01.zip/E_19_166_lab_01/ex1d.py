from urllib import request

response = request.urlopen("http://eng.pdn.ac.lk")
body = response.read()
response.close()
typeb = type(body)
print(typeb)
