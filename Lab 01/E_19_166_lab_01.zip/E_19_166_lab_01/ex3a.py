import requests
import json
from typing import List

def ddg_query(search_term: str, nr_result: int) -> List[str]:
    serach_term = requests.utils.quote(search_term)
    response = requests.get(f"https://api.duckduckgo.com/?q={search_term}&format=json")

    data = json.loads(response.text)

    urls = [result['FirstURL'] for result in data['Results']]

    return urls[:nr_result]

print(ddg_query("University of Peradeniya", 1))
