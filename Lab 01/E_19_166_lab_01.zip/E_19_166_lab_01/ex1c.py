from urllib import request

response = request.urlopen("http://eng.pdn.ac.lk")
body = response.read()
size = len(body)
response.close()

print(size)
