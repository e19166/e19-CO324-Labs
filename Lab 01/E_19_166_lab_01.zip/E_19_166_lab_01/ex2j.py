from urllib import request, parse

encoded = parse.quote("Rocco's basilisk")
with request.urlopen("https://www.duckduckgo.com/?q={url_encoded_query}") as query:

    headers = query.headers.items()
    body = query.read()
    
print(headers)
print(body)
