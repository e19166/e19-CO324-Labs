import grpc
from concurrent import futures
import tasks_pb2
import tasks_pb2_grpc

# defining the tasks
tasks = [{"id": "1", "title": "Task 1", "description": "Description 1"},
         {"id": "2", "title": "Task 2", "description": "Description 2"}
         ]

class TaskService(tasks_pb2_grpc.TaskServiceServicer):
    def __init__(self):
        self.tasks = []

    def CreateTask(self, request, context):
       # Generate a unique ID (you might use a library like UUID in a real-world scenario)
        new_id = str(len(self.tasks) + 1)
        request.id = new_id

        # Add the new task to the list
        self.tasks.append(request)

        return request

    def GetTask(self, request, context):
        # Implement logic to retrieve a task by its ID and return it.
        task_id = request.id
        
        #
        task = next((t for t in tasks if t["id"] == task_id), None)
        
        # condition when the task is found
        if task:
            task_message = tasks_pb2.Task(
                id = task["id"],
                title = task["title"],
                description = task["description"]
            )
            return task_message
        
        # condition when the task is not found
        else:
            context.set_code(grpc.StatusCode.NOT_FOUND)
            context.set_details(f"Task with ID '{task_id}' not found.")
            return tasks_pb2.Task()
        

    def UpdateTask(self, request, context):
        # Implement logic to update an existing task and return the updated task.
        task_id = request.id
        
        task = next((t for t in tasks if t["id"] == task_id), None)
        
        
        if task:
            task["title"] = request.title
            task["description"] = request.description
            
            updated_task_message = tasks_pb2.Task(
                id = task["id"],
                title = task["title"],
                description = task["description"]
            )
            
            return updated_task_message
        
        else:
            context.set_code(grpc.StatusCode.NOT_FOUND)
            context.set_details(f"Task with ID '{task_id}' not found.")
            return tasks_pb2.Task()

    def DeleteTask(self, request, context):
        # Implement logic to delete a task by its ID and return the result.
        task_id = request.id
        
        task = next((t for t in tasks if t["id"] == task_id), None)
        
        if task:
            tasks.remove(task)
            
            return tasks_pb2.DeleteTaskResponse(success = True)
        
        else:
            context.set_code(grpc.StatusCode.NOT_FOUND)
            context.set_details(f"Task with ID '{task_id}' not found.")
            return tasks_pb2.DeleteTaskResponse(success = False)

def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    tasks_pb2_grpc.add_TaskServiceServicer_to_server(TaskService(), server)
    server.add_insecure_port('[::]:50051')
    server.start()
    print("Server started on port 50051...")
    server.wait_for_termination()

if __name__ == '__main__':
    serve()
